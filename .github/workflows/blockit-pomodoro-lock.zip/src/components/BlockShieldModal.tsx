import React from 'react';
import { 
  ShieldAlert, 
  X, 
  Phone, 
  MessageSquareText, 
  MessageCircle 
} from 'lucide-react';
import { AppInfo } from '../types';

interface BlockShieldModalProps {
  blockedApp: AppInfo | null;
  secondsRemaining: number;
  onClose: () => void;
}

const MOTIVATIONAL_QUOTES = [
  "STARVE DISTRACTIONS, FEED YOUR FOCUS!",
  "YOU CHOSE THIS POMODORO LOCK. STAY IN THE GAME!",
  "GREATNESS DEMANDS UNINTERRUPTED CONCENTRATION.",
  "YOUR FUTURE SELF WILL THANK YOU FOR CLOSING THAT APP!",
  "FOCUS IS A MUSCLE. LEVEL IT UP RIGHT NOW!"
];

export const BlockShieldModal: React.FC<BlockShieldModalProps> = ({
  blockedApp,
  secondsRemaining,
  onClose,
}) => {
  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeString = `${mins}M ${secs.toString().padStart(2, '0')}S`;

  // Random quote selector
  const quote = MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 flex items-center justify-center p-4 animate-fade-in font-pixel">
      <div className="bg-slate-900 border-4 border-black pixel-border-rose p-6 max-w-md w-full relative space-y-5 text-center text-slate-100">

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1.5 bg-slate-800 border-2 border-black pixel-button text-slate-300 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Badge */}
        <div className="space-y-3">
          <div className="w-14 h-14 bg-rose-600 border-2 border-black pixel-border-sm text-white mx-auto flex items-center justify-center shadow-[3px_3px_0px_#000]">
            <ShieldAlert className="w-7 h-7 animate-bounce" />
          </div>

          <div>
            <div className="inline-block bg-rose-600 text-white px-3 py-1 text-[10px] border-2 border-black pixel-border-sm mb-1">
              {blockedApp ? `${blockedApp.name.toUpperCase()} BLOCKED!` : 'POMODORO SHIELD ACTIVE'}
            </div>
            <h3 className="text-xl sm:text-2xl font-pixel text-rose-500 drop-shadow-[2px_2px_0px_#000]">
              STAY LOCKED IN!
            </h3>
          </div>
        </div>

        {/* Countdown notice */}
        <div className="bg-slate-950 p-4 border-2 border-slate-800 space-y-1 crt-scanlines">
          <p className="text-[10px] text-slate-400 font-silkscreen">LOCK TIME REMAINING</p>
          <div className="text-2xl sm:text-3xl font-pixel text-emerald-400">
            {timeString}
          </div>
        </div>

        {/* Quote */}
        <div className="bg-slate-950 p-3 border-2 border-slate-800 text-amber-300 text-[10px] font-silkscreen leading-relaxed">
          "{quote}"
        </div>

        {/* Permitted Apps Quick Launcher */}
        <div className="space-y-2 text-left">
          <p className="text-[9px] font-pixel text-slate-400">
            PERMITTED UNLOCKED APPS (3)
          </p>
          <div className="grid grid-cols-3 gap-2 text-[9px] font-silkscreen">
            <div className="bg-slate-950 p-2 border border-emerald-500/50 flex items-center gap-1.5 text-emerald-400">
              <Phone className="w-3.5 h-3.5 text-emerald-400" /> Phone
            </div>
            <div className="bg-slate-950 p-2 border border-teal-500/50 flex items-center gap-1.5 text-teal-400">
              <MessageSquareText className="w-3.5 h-3.5 text-teal-400" /> WhatsApp
            </div>
            <div className="bg-slate-950 p-2 border border-indigo-500/50 flex items-center gap-1.5 text-indigo-400">
              <MessageCircle className="w-3.5 h-3.5 text-indigo-400" /> Messages
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-1">
          <button
            onClick={onClose}
            className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-2 border-black pixel-button font-pixel text-xs"
          >
            RETURN TO FOCUS
          </button>
        </div>
      </div>
    </div>
  );
};

