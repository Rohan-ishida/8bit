import React, { useState } from 'react';
import { 
  Phone, 
  MessageSquareText, 
  MessageCircle, 
  Instagram, 
  Youtube, 
  Video, 
  Globe, 
  Twitter, 
  Gamepad2, 
  Lock, 
  ShieldAlert, 
  Flame, 
  Coffee, 
  Play, 
  Pause, 
  SkipForward, 
  Radio, 
  Grid,
  Maximize2
} from 'lucide-react';
import { AppId, AppInfo, TimerPhase } from '../types';
import { PhoneApp } from './apps/PhoneApp';
import { WhatsAppApp } from './apps/WhatsAppApp';
import { MessagesApp } from './apps/MessagesApp';
import { Contact, ChatMessage, CallLog } from '../types';

interface FocusOSLauncherProps {
  timerPhase: TimerPhase;
  secondsRemaining: number;
  currentSession: number;
  totalSessions: number;
  allApps: AppInfo[];
  contacts: Contact[];
  chats: Record<string, ChatMessage[]>;
  callLogs: CallLog[];
  onPause: () => void;
  onResume: () => void;
  onSkip: () => void;
  onBlockedAppClick: (app: AppInfo) => void;
  onSendMessage: (contactId: string, text: string) => void;
  onMakeCall: (contactName: string, phone: string) => void;
  onAddContact: (contact: Contact) => void;
}

export const FocusOSLauncher: React.FC<FocusOSLauncherProps> = ({
  timerPhase,
  secondsRemaining,
  currentSession,
  totalSessions,
  allApps,
  contacts,
  chats,
  callLogs,
  onPause,
  onResume,
  onSkip,
  onBlockedAppClick,
  onSendMessage,
  onMakeCall,
  onAddContact,
}) => {
  const [activeAppId, setActiveAppId] = useState<AppId | null>(null);

  // Time format MM:SS
  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeString = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

  const renderAppIcon = (id: AppId) => {
    switch (id) {
      case 'phone': return <Phone className="w-5 h-5 text-emerald-400" />;
      case 'whatsapp': return <MessageSquareText className="w-5 h-5 text-teal-400" />;
      case 'messages': return <MessageCircle className="w-5 h-5 text-indigo-400" />;
      case 'instagram': return <Instagram className="w-5 h-5 text-pink-400 opacity-60" />;
      case 'youtube': return <Youtube className="w-5 h-5 text-red-400 opacity-60" />;
      case 'tiktok': return <Video className="w-5 h-5 text-slate-400 opacity-60" />;
      case 'chrome': return <Globe className="w-5 h-5 text-blue-400 opacity-60" />;
      case 'twitter': return <Twitter className="w-5 h-5 text-sky-400 opacity-60" />;
      case 'games': return <Gamepad2 className="w-5 h-5 text-amber-400 opacity-60" />;
      default: return <Grid className="w-5 h-5 text-slate-400" />;
    }
  };

  const allowedApps = allApps.filter(a => a.isAllowed);
  const blockedApps = allApps.filter(a => !a.isAllowed);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 font-pixel">
      {/* Mock 8-Bit Smartphone Frame */}
      <div className="bg-slate-900 p-4 sm:p-5 border-4 border-black pixel-border relative overflow-hidden text-slate-100">
        
        {/* Top 8-Bit Retro Status Bar */}
        <div className="flex items-center justify-between px-3 py-1.5 bg-slate-950 border-2 border-slate-800 mb-4 text-[10px] font-silkscreen text-slate-300">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-emerald-500 animate-ping"></span>
            <span className="text-emerald-400 font-pixel">{timeString}</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="bg-rose-600 text-white px-1.5 py-0.5 text-[9px] border border-black font-pixel">
              8-BIT LOCK
            </span>
            <span>BAT 100% 🔋</span>
          </div>
        </div>

        {/* Live Timer Widget inside OS Launcher */}
        <div className="bg-slate-950 border-2 border-slate-800 p-4 mb-5 flex flex-col sm:flex-row items-center justify-between gap-3 crt-scanlines">
          <div className="space-y-1 text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-rose-600 text-white text-[9px] border border-black">
              <Flame className="w-3 h-3" />
              <span>STAGE {currentSession} / {totalSessions}</span>
            </div>
            <div className="text-2xl sm:text-3xl font-pixel text-emerald-400 drop-shadow-[2px_2px_0px_#000]">
              {timeString}
            </div>
          </div>

          <div className="flex items-center gap-1.5 font-pixel text-[10px]">
            {timerPhase === 'paused' ? (
              <button
                onClick={onResume}
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-2 border-black pixel-button flex items-center gap-1"
              >
                <Play className="w-3 h-3 fill-slate-950" /> RESUME
              </button>
            ) : (
              <button
                onClick={onPause}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border-2 border-black pixel-button flex items-center gap-1"
              >
                <Pause className="w-3 h-3 fill-slate-200" /> PAUSE
              </button>
            )}

            <button
              onClick={onSkip}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border-2 border-black pixel-button"
              title="Skip Session"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* If an allowed app is currently open, display it */}
        {activeAppId ? (
          <div className="space-y-3 animate-fade-in">
            <div className="flex items-center justify-between px-1">
              <span className="text-[10px] font-pixel text-emerald-400">
                ACTIVE APP VIEW
              </span>
              <button
                onClick={() => setActiveAppId(null)}
                className="text-[10px] font-pixel px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border-2 border-black pixel-button flex items-center gap-1"
              >
                <Grid className="w-3 h-3" /> EXIT APP
              </button>
            </div>

            {activeAppId === 'phone' && (
              <PhoneApp
                contacts={contacts}
                callLogs={callLogs}
                onMakeCall={onMakeCall}
                onAddContact={onAddContact}
              />
            )}

            {activeAppId === 'whatsapp' && (
              <WhatsAppApp
                contacts={contacts}
                chats={chats}
                onSendMessage={onSendMessage}
                onMakeCall={onMakeCall}
              />
            )}

            {activeAppId === 'messages' && (
              <MessagesApp
                contacts={contacts}
                chats={chats}
                onSendMessage={onSendMessage}
              />
            )}
          </div>
        ) : (
          /* FOCUS OS LAUNCHER APPS GRID */
          <div className="space-y-5">
            {/* 1. PERMITTED APPS SECTION (Strict 3 Apps) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b-2 border-slate-800 pb-1.5">
                <h4 className="text-[10px] font-pixel text-emerald-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 bg-emerald-500"></span>
                  UNLOCKED APPS (3 PERMITTED)
                </h4>
                <span className="text-[9px] text-slate-400 font-silkscreen">CLICK TO LAUNCH</span>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                {allowedApps.map(app => (
                  <button
                    key={app.id}
                    onClick={() => setActiveAppId(app.id)}
                    className="bg-slate-950 p-3.5 border-2 border-emerald-500 pixel-border-emerald flex flex-col items-center justify-center gap-2 group transition-all pixel-button cursor-pointer"
                  >
                    <div className="p-2 bg-emerald-950 border border-emerald-500 text-emerald-300">
                      {renderAppIcon(app.id)}
                    </div>
                    <span className="font-pixel text-[10px] text-white">{app.name}</span>
                    <span className="text-[8px] font-silkscreen text-emerald-400 bg-emerald-950 px-1 border border-emerald-800">
                      UNLOCKED
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* 2. BLOCKED APPS SECTION */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b-2 border-slate-800 pb-1.5">
                <h4 className="text-[10px] font-pixel text-rose-400 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-rose-400" />
                  BLOCKED DISTRACTIONS
                </h4>
                <span className="text-[9px] text-slate-400 font-silkscreen">SHIELD ENGAGED</span>
              </div>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {blockedApps.map(app => (
                  <button
                    key={app.id}
                    onClick={() => onBlockedAppClick(app)}
                    className="bg-slate-950 p-2.5 border-2 border-slate-800 flex flex-col items-center justify-center gap-1 opacity-70 hover:opacity-100 transition-all pixel-button cursor-pointer relative"
                  >
                    <div className="relative">
                      {renderAppIcon(app.id)}
                      <div className="absolute -top-1 -right-1 p-0.5 bg-rose-600 text-white">
                        <Lock className="w-2.5 h-2.5" />
                      </div>
                    </div>
                    <span className="text-[8px] font-silkscreen text-slate-400 truncate w-full text-center">
                      {app.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

