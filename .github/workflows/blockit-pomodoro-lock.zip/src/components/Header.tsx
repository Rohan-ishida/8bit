import React, { useState } from 'react';
import { Shield, Flame, Volume2, VolumeX, BarChart3, Radio, Smartphone, Heart } from 'lucide-react';
import { PomodoroSettings, TimerPhase } from '../types';
import { AndroidApkModal } from './AndroidApkModal';

interface HeaderProps {
  settings: PomodoroSettings;
  onUpdateSettings: (newSettings: PomodoroSettings) => void;
  streakDays: number;
  timerPhase: TimerPhase;
  onOpenStats: () => void;
  onToggleAmbientDrawer: () => void;
  isAmbientPlaying: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onUpdateSettings,
  streakDays,
  timerPhase,
  onOpenStats,
  onToggleAmbientDrawer,
  isAmbientPlaying,
}) => {
  const [showApkModal, setShowApkModal] = useState(false);
  const isLockActive = timerPhase === 'work' || timerPhase === 'paused';

  return (
    <>
      <header className="w-full bg-slate-900 border-b-4 border-black text-slate-100 px-3 py-2.5 sticky top-0 z-30 font-pixel">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
          
          {/* Logo & Status */}
          <div className="flex items-center gap-2.5">
            <div className="relative">
              <div className={`p-2 border-2 border-black pixel-border-sm flex items-center justify-center ${
                isLockActive 
                  ? 'bg-rose-600 text-white animate-pulse' 
                  : 'bg-emerald-500 text-slate-950'
              }`}>
                <Shield className="w-5 h-5" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-pixel text-xs sm:text-sm tracking-wide text-emerald-400 drop-shadow-[2px_2px_0px_#000]">
                  BLOCK-IT 8-BIT
                </h1>
                <span className="hidden sm:inline-block text-[9px] uppercase px-1.5 py-0.5 bg-rose-600 text-white border border-black font-silkscreen">
                  {isLockActive ? 'LOCKED' : 'READY'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-silkscreen hidden md:block">
                {isLockActive ? 'STAGE ACTIVE • DISTRACTIONS BLOCKED' : '8-BIT RETRO POMODORO LOCK'}
              </p>
            </div>
          </div>

          {/* Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* APK Guide Button */}
            <button
              onClick={() => setShowApkModal(true)}
              className="flex items-center gap-1 px-2 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-[10px] sm:text-xs font-pixel border-2 border-black pixel-button"
              title="Download Android APK & Installation Guide"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">APK GUIDE</span>
            </button>

            {/* Daily Streak Badge */}
            <button
              onClick={onOpenStats}
              title="View Focus Streak & Hearts"
              className="flex items-center gap-1 px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-400 text-[10px] sm:text-xs font-pixel border-2 border-black pixel-button"
            >
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 animate-pulse" />
              <span>{streakDays}D</span>
            </button>

            {/* Ambient Sound Trigger */}
            <button
              onClick={onToggleAmbientDrawer}
              title="8-Bit Ambient Sounds"
              className={`p-1.5 border-2 border-black text-[10px] font-pixel pixel-button flex items-center gap-1 ${
                isAmbientPlaying
                  ? 'bg-teal-400 text-slate-950'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${isAmbientPlaying ? 'animate-spin' : ''}`} />
            </button>

            {/* Sound Toggle */}
            <button
              onClick={() => onUpdateSettings({ ...settings, soundEnabled: !settings.soundEnabled })}
              title={settings.soundEnabled ? 'Mute 8-Bit Tones' : 'Unmute 8-Bit Tones'}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 border-2 border-black text-slate-200 pixel-button"
            >
              {settings.soundEnabled ? (
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <VolumeX className="w-3.5 h-3.5 text-slate-500" />
              )}
            </button>

            {/* Analytics / Stats Modal Trigger */}
            <button
              onClick={onOpenStats}
              title="8-Bit High Scores & Logs"
              className="p-1.5 bg-slate-800 hover:bg-slate-700 border-2 border-black text-slate-200 pixel-button"
            >
              <BarChart3 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* APK Guide Modal */}
      {showApkModal && (
        <AndroidApkModal onClose={() => setShowApkModal(false)} />
      )}
    </>
  );
};

