import React, { useState } from 'react';
import { Smartphone, Download, Shield, CheckCircle2, Copy, AlertTriangle, ExternalLink, X, Terminal, Sparkles } from 'lucide-react';

interface AndroidApkModalProps {
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk' | 'blocking'>('pwa');
  const [copied, setCopied] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopySnippet = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(label);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const MANIFEST_SNIPPET = `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.blockit.focusos">

    <!-- Native System-Level Blocking Permissions -->
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" tools:ignore="ProtectedPermissions" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />

    <application ...>
        <!-- Accessibility Service for Instant App Interception -->
        <service
            android:name=".FocusBlockerAccessibilityService"
            android:label="BlockIt Focus Shield"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>
    </application>
</manifest>`;

  const KOTLIN_SERVICE_SNIPPET = `package com.blockit.focusos

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusBlockerAccessibilityService : AccessibilityService() {
    private val BLOCKED_PACKAGES = setOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.zhiliaoapp.musically", // TikTok
        "com.twitter.android",
        "com.android.chrome"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            
            // Check if user launched a blocked distraction app
            if (BLOCKED_PACKAGES.contains(packageName)) {
                // Redirect back to BlockIt Focus OS Home Screen instantly!
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
            }
        }
    }

    override fun onInterrupt() {}
}`;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fade-in">
      <div className="bg-slate-900 border-4 border-emerald-500 rounded-none max-w-2xl w-full pixel-border p-4 sm:p-6 text-slate-100 space-y-5 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b-4 border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-500 text-slate-950 p-2 font-pixel text-xs border-2 border-black">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-pixel text-emerald-400 text-sm sm:text-base">ANDROID APK & FOCUS GUIDE</h2>
              <p className="text-xs text-slate-400 font-silkscreen mt-1">Get 8-Bit Focus OS on your Android device</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border-2 border-black pixel-button"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-2 font-pixel text-[10px] sm:text-xs">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`p-2.5 text-center border-2 border-black pixel-button ${
              activeTab === 'pwa' 
                ? 'bg-emerald-500 text-slate-950 font-bold' 
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            ⚡ INSTANT APP (PWA)
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`p-2.5 text-center border-2 border-black pixel-button ${
              activeTab === 'apk' 
                ? 'bg-emerald-500 text-slate-950 font-bold' 
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            📦 NATIVE APK
          </button>
          <button
            onClick={() => setActiveTab('blocking')}
            className={`p-2.5 text-center border-2 border-black pixel-button ${
              activeTab === 'blocking' 
                ? 'bg-emerald-500 text-slate-950 font-bold' 
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🛡️ HOW BLOCKING WORKS
          </button>
        </div>

        {/* Tab 1: Instant PWA Install on Android */}
        {activeTab === 'pwa' && (
          <div className="space-y-4 bg-slate-950 p-4 border-2 border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-pixel text-xs">
              <Sparkles className="w-4 h-4" />
              <span>EASIEST & RECOMMENDED (NO COMPILING NEEDED)</span>
            </div>
            <p className="text-xs text-slate-300 font-silkscreen leading-relaxed">
              You can install this app directly on your Android phone as a full-screen, standalone app with its own 8-bit home icon in less than 10 seconds!
            </p>

            <div className="space-y-2.5 text-xs text-slate-200">
              <div className="flex items-start gap-3 bg-slate-900 p-2.5 border border-slate-800">
                <span className="font-pixel text-emerald-400 bg-slate-800 px-2 py-1 text-[10px]">STEP 1</span>
                <div>
                  <p className="font-bold">Open this URL in Chrome on Android:</p>
                  <div className="flex items-center gap-2 mt-1">
                    <input 
                      type="text" 
                      readOnly 
                      value={window.location.href} 
                      className="bg-slate-950 border border-slate-700 text-emerald-400 text-[10px] px-2 py-1 font-mono flex-1 rounded-none select-all"
                    />
                    <button 
                      onClick={handleCopyUrl}
                      className="bg-emerald-600 hover:bg-emerald-500 text-slate-950 px-2.5 py-1 text-[10px] font-pixel border border-black pixel-button"
                    >
                      {copied ? 'COPIED!' : 'COPY'}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-slate-900 p-2.5 border border-slate-800">
                <span className="font-pixel text-emerald-400 bg-slate-800 px-2 py-1 text-[10px]">STEP 2</span>
                <p className="text-xs">
                  Tap the Chrome menu button <span className="font-bold text-emerald-400">(⋮ 3 vertical dots)</span> in the top-right corner of Chrome.
                </p>
              </div>

              <div className="flex items-start gap-3 bg-slate-900 p-2.5 border border-slate-800">
                <span className="font-pixel text-emerald-400 bg-slate-800 px-2 py-1 text-[10px]">STEP 3</span>
                <p className="text-xs">
                  Select <span className="font-bold text-emerald-400">"Add to Home screen"</span> or <span className="font-bold text-emerald-400">"Install App"</span>.
                </p>
              </div>

              <div className="flex items-start gap-3 bg-slate-900 p-2.5 border border-slate-800">
                <span className="font-pixel text-emerald-400 bg-slate-800 px-2 py-1 text-[10px]">STEP 4</span>
                <p className="text-xs">
                  Open <span className="font-bold text-emerald-400">"BlockIt 8-Bit Focus"</span> directly from your Android home screen in immersive full screen!
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Export Native Android APK */}
        {activeTab === 'apk' && (
          <div className="space-y-4 bg-slate-950 p-4 border-2 border-slate-800">
            <div className="flex items-center gap-2 text-sky-400 font-pixel text-xs">
              <Download className="w-4 h-4" />
              <span>BUILD AN UNTIMED NATIVE .APK FILE</span>
            </div>
            <p className="text-xs text-slate-300 font-silkscreen leading-relaxed">
              To turn this project into a standalone Android binary (<code className="text-amber-400">.apk</code>), export the source code from AI Studio:
            </p>

            <div className="space-y-2.5 text-xs text-slate-200">
              <div className="bg-slate-900 p-3 border border-slate-800 space-y-1">
                <p className="font-bold text-amber-400 font-pixel text-[11px]">1. Export Source Code</p>
                <p className="text-slate-300">Click <span className="text-white font-bold">Settings (⚙️)</span> at the top-right menu of AI Studio → Select <span className="text-white font-bold">Export ZIP</span> or <span className="text-white font-bold">Export to GitHub</span>.</p>
              </div>

              <div className="bg-slate-900 p-3 border border-slate-800 space-y-2">
                <p className="font-bold text-amber-400 font-pixel text-[11px]">2. Wrap with Capacitor / Bubblewrap</p>
                <p className="text-slate-300 text-[11px]">In your terminal inside the unzipped folder, run:</p>
                <div className="bg-black p-2 border border-slate-800 font-mono text-[10px] text-emerald-400 space-y-1">
                  <p>npm install @capacitor/core @capacitor/cli @capacitor/android</p>
                  <p>npx cap init "BlockIt Focus" "com.blockit.focusos"</p>
                  <p>npm run build</p>
                  <p>npx cap add android</p>
                  <p>npx cap open android</p>
                </div>
              </div>

              <div className="bg-slate-900 p-3 border border-slate-800 space-y-1">
                <p className="font-bold text-amber-400 font-pixel text-[11px]">3. Build APK in Android Studio</p>
                <p className="text-slate-300">In Android Studio, click <span className="text-white font-bold">Build → Build Bundle(s) / APK(s) → Build APK(s)</span>. Transfer the output <code className="text-emerald-400">app-debug.apk</code> to your Android device!</p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: How Blocking Works & Native System-Level APK Setup */}
        {activeTab === 'blocking' && (
          <div className="space-y-4 bg-slate-950 p-4 border-2 border-slate-800 max-h-[60vh] overflow-y-auto">
            <div className="flex items-center gap-2 text-rose-400 font-pixel text-xs">
              <Shield className="w-4 h-4" />
              <span>NATIVE SYSTEM-LEVEL BLOCKING IN ANDROID APK</span>
            </div>

            <div className="bg-slate-900 p-3 border-2 border-rose-900/50 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Web Apps vs. Native Android Permissions:</span>
              </div>
              <p className="text-slate-300 text-xs leading-relaxed">
                Because web browsers run inside a secure sandbox, a Web App or PWA cannot kill external Android apps directly. However, when compiled into a <span className="text-emerald-400 font-bold font-mono">Native Android APK</span> using Capacitor, you can grant <span className="text-amber-400 font-bold font-mono">AccessibilityService</span> and <span className="text-amber-400 font-bold font-mono">PACKAGE_USAGE_STATS</span> to block other apps at the OS level!
              </p>
            </div>

            {/* Step-by-Step Android Manifest & Accessibility Service */}
            <div className="space-y-3">
              <div className="bg-slate-900 p-3 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-400 font-pixel text-[11px]">1. AndroidManifest.xml Configuration</span>
                  <button
                    onClick={() => handleCopySnippet(MANIFEST_SNIPPET, 'manifest')}
                    className="bg-slate-800 hover:bg-slate-700 text-emerald-400 px-2 py-1 text-[9px] font-pixel border border-black pixel-button flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedCode === 'manifest' ? 'COPIED!' : 'COPY MANIFEST'}</span>
                  </button>
                </div>
                <pre className="bg-black p-2 border border-slate-800 text-[9px] font-mono text-emerald-400 overflow-x-auto">
                  {MANIFEST_SNIPPET}
                </pre>
              </div>

              <div className="bg-slate-900 p-3 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-400 font-pixel text-[11px]">2. Native Kotlin Accessibility Service</span>
                  <button
                    onClick={() => handleCopySnippet(KOTLIN_SERVICE_SNIPPET, 'kotlin')}
                    className="bg-slate-800 hover:bg-slate-700 text-emerald-400 px-2 py-1 text-[9px] font-pixel border border-black pixel-button flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedCode === 'kotlin' ? 'COPIED!' : 'COPY KOTLIN CODE'}</span>
                  </button>
                </div>
                <pre className="bg-black p-2 border border-slate-800 text-[9px] font-mono text-sky-400 overflow-x-auto max-h-48">
                  {KOTLIN_SERVICE_SNIPPET}
                </pre>
              </div>

              <div className="bg-slate-900 p-3 border border-slate-800 space-y-2 text-xs">
                <p className="font-bold text-amber-400 font-pixel text-[11px]">3. Enabling Permissions on Android Device:</p>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-[11px]">
                  <li>Install the built APK on your Android phone.</li>
                  <li>Go to <span className="text-white font-bold">Android Settings → Accessibility</span> → Turn on <span className="text-emerald-400 font-bold">BlockIt Focus Shield</span>.</li>
                  <li>Go to <span className="text-white font-bold">Android Settings → Apps → Special App Access → Usage Access</span> → Enable <span className="text-emerald-400 font-bold">BlockIt Focus</span>.</li>
                  <li>Whenever Instagram, YouTube, or TikTok is opened during a timer session, Android will immediately intercept and return to BlockIt Focus OS!</li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* Footer Close Button */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-pixel text-xs px-5 py-2.5 border-2 border-black pixel-button"
          >
            GOT IT! [RETURN TO GAME]
          </button>
        </div>

      </div>
    </div>
  );
};
