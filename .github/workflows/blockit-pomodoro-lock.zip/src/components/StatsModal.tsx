import React from 'react';
import { 
  BarChart3, 
  Flame, 
  X, 
  Clock, 
  CheckCircle2, 
  ShieldAlert, 
  Calendar,
  Zap,
  TrendingUp,
  Award
} from 'lucide-react';
import { FocusSessionRecord, DayStreak, BlockedAttempt } from '../types';

interface StatsModalProps {
  streak: DayStreak;
  sessionHistory: FocusSessionRecord[];
  blockedAttempts: BlockedAttempt[];
  onClose: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  streak,
  sessionHistory,
  blockedAttempts,
  onClose,
}) => {
  const totalWorkMins = sessionHistory.reduce((acc, s) => acc + s.totalWorkMinutes, 0);
  const totalSessionsCompleted = sessionHistory.reduce((acc, s) => acc + s.completedSessions, 0);

  // Group blocked attempts by app name
  const appBlockCounts: Record<string, number> = {};
  blockedAttempts.forEach(b => {
    appBlockCounts[b.appName] = (appBlockCounts[b.appName] || 0) + 1;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 flex items-center justify-center p-4 animate-fade-in font-pixel text-slate-100">
      <div className="bg-slate-900 border-4 border-black pixel-border p-5 sm:p-6 max-w-xl w-full max-h-[85vh] overflow-y-auto space-y-5 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 p-1.5 bg-slate-800 border-2 border-black pixel-button text-slate-300 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 border-b-2 border-slate-800 pb-3">
          <div className="p-2.5 bg-amber-500 text-slate-950 border-2 border-black pixel-border-sm">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-pixel text-lg text-amber-400 drop-shadow-[2px_2px_0px_#000]">HIGH SCORES & STATS</h3>
            <p className="text-[9px] text-slate-400 font-silkscreen">8-BIT FOCUS RECORD & SHIELD LOGS</p>
          </div>
        </div>

        {/* Highlight Metrics */}
        <div className="grid grid-cols-3 gap-2.5">
          {/* Metric 1: Streak */}
          <div className="bg-slate-950 p-3 border-2 border-amber-500 flex flex-col items-center text-center">
            <Flame className="w-5 h-5 text-amber-400 mb-1" />
            <span className="text-xl font-pixel text-amber-300">{streak.currentStreak}</span>
            <span className="text-[8px] font-silkscreen text-slate-400 mt-0.5">DAY STREAK</span>
          </div>

          {/* Metric 2: Total Focus Mins */}
          <div className="bg-slate-950 p-3 border-2 border-indigo-500 flex flex-col items-center text-center">
            <Clock className="w-5 h-5 text-indigo-400 mb-1" />
            <span className="text-xl font-pixel text-indigo-300">{totalWorkMins}M</span>
            <span className="text-[8px] font-silkscreen text-slate-400 mt-0.5">FOCUS TIME</span>
          </div>

          {/* Metric 3: Completed Pomodoros */}
          <div className="bg-slate-950 p-3 border-2 border-emerald-500 flex flex-col items-center text-center">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 mb-1" />
            <span className="text-xl font-pixel text-emerald-300">{totalSessionsCompleted}</span>
            <span className="text-[8px] font-silkscreen text-slate-400 mt-0.5">STAGES DONE</span>
          </div>
        </div>

        {/* Blocked App Attempts Summary */}
        <div className="space-y-2 bg-slate-950 p-3.5 border-2 border-slate-800 crt-scanlines">
          <div className="flex items-center justify-between">
            <h4 className="text-[9px] font-pixel text-rose-400 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
              BLOCKED ATTEMPTS ({blockedAttempts.length})
            </h4>
            <span className="text-[8px] font-silkscreen text-slate-500">8-BIT SHIELD</span>
          </div>

          {Object.keys(appBlockCounts).length > 0 ? (
            <div className="space-y-1.5 font-silkscreen text-[10px]">
              {Object.entries(appBlockCounts).map(([appName, count]) => (
                <div
                  key={appName}
                  className="bg-slate-900 p-2 border border-slate-800 flex items-center justify-between"
                >
                  <span className="text-slate-200">{appName}</span>
                  <span className="px-1.5 py-0.5 bg-rose-950 text-rose-400 border border-rose-800 text-[9px]">
                    {count} BLOCKED
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[9px] font-silkscreen text-slate-500 text-center py-2">
              NO DISTRACTION ATTEMPTS LOGGED! PURE CONCENTRATION. 🎯
            </p>
          )}
        </div>

        {/* Recent Session History */}
        <div className="space-y-2">
          <h4 className="text-[9px] font-pixel text-slate-300 flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            DAILY LEADERBOARD LOGS
          </h4>

          <div className="space-y-1.5 font-silkscreen text-[10px]">
            {sessionHistory.slice(-5).map(record => (
              <div
                key={record.id}
                className="bg-slate-950 p-2.5 border border-slate-800 flex items-center justify-between"
              >
                <div>
                  <div className="text-slate-200 font-pixel text-[10px]">{record.date}</div>
                  <div className="text-[8px] text-slate-400">
                    {record.completedSessions} / {record.targetSessions} STAGES
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-indigo-400 font-pixel text-[10px]">{record.totalWorkMinutes} MINS</div>
                  <div className="text-[8px] text-slate-500">{record.blockedAttemptsCount} BLOCKS</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-pixel text-xs border-2 border-black pixel-button"
        >
          CLOSE HIGH SCORES
        </button>
      </div>
    </div>
  );
};

