import React from 'react';
import { Play, Pause, Flame, Coffee, ShieldCheck, Lock, Heart } from 'lucide-react';
import { TimerPhase } from '../types';

interface TimerDisplayProps {
  phase: TimerPhase;
  secondsRemaining: number;
  totalPhaseSeconds: number;
  currentSession: number;
  totalSessions: number;
  onPause: () => void;
  onResume: () => void;
}

export const TimerDisplay: React.FC<TimerDisplayProps> = ({
  phase,
  secondsRemaining,
  totalPhaseSeconds,
  currentSession,
  totalSessions,
  onPause,
  onResume,
}) => {
  const isPaused = phase === 'paused';
  const isWork = phase === 'work';
  const isShortBreak = phase === 'shortBreak';
  const isLongBreak = phase === 'longBreak';

  // Format time MM:SS
  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeString = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

  const progressPercent = totalPhaseSeconds > 0 ? Math.round((secondsRemaining / totalPhaseSeconds) * 100) : 0;

  const getPhaseTitle = () => {
    if (isWork) return 'STAGE 1: DEEP FOCUS';
    if (isShortBreak) return 'REST BREAK 1';
    if (isLongBreak) return 'RECOVERY STAGE';
    if (isPaused) return 'PAUSED';
    return 'MISSION COMPLETE';
  };

  return (
    <div className="bg-slate-900 border-4 border-black pixel-border p-5 sm:p-6 flex flex-col items-center justify-center text-center space-y-5 max-w-lg mx-auto relative font-pixel">
      
      {/* 8-Bit Stage & Session Badge */}
      <div className="flex flex-col items-center gap-2 z-10 w-full">
        <div className={`px-3 py-1 text-xs border-2 border-black pixel-border-sm flex items-center gap-2 ${
          isWork ? 'bg-rose-600 text-white animate-pulse' : 'bg-teal-500 text-slate-950'
        }`}>
          {isWork && <Flame className="w-3.5 h-3.5" />}
          {(isShortBreak || isLongBreak) && <Coffee className="w-3.5 h-3.5" />}
          <span>{getPhaseTitle()}</span>
        </div>

        <div className="flex items-center justify-between w-full text-[10px] text-slate-300 font-silkscreen px-2">
          <span>LEVEL {currentSession} / {totalSessions}</span>
          {/* Hearts indicator */}
          <div className="flex items-center gap-1">
            {Array.from({ length: Math.min(5, totalSessions) }).map((_, i) => (
              <Heart 
                key={i} 
                className={`w-3 h-3 ${i < currentSession ? 'text-rose-500 fill-rose-500' : 'text-slate-700'}`} 
              />
            ))}
          </div>
        </div>
      </div>

      {/* 8-Bit Pixel Digital Screen */}
      <div className="w-full bg-slate-950 border-4 border-slate-800 p-6 flex flex-col items-center justify-center space-y-3 crt-scanlines">
        <div className="text-3xl sm:text-5xl font-pixel text-emerald-400 drop-shadow-[3px_3px_0px_#000] tracking-widest">
          {timeString}
        </div>

        {/* 8-Bit Pixel Progress Bar */}
        <div className="w-full bg-slate-900 border-2 border-slate-700 h-4 p-0.5 relative">
          <div 
            className={`h-full border border-black transition-all duration-500 ${
              isWork ? 'bg-rose-500' : 'bg-teal-400'
            }`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-silkscreen">
          <Lock className="w-3 h-3 text-rose-400" />
          <span>8-BIT FOCUS SHIELD ENGAGED ({progressPercent}%)</span>
        </div>
      </div>

      {/* Control Buttons */}
      <div className="flex items-center gap-2 z-10 w-full justify-center font-pixel text-xs">
        {/* Pause / Resume */}
        {isPaused ? (
          <button
            onClick={onResume}
            className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-2 border-black pixel-button flex items-center justify-center gap-2"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>RESUME</span>
          </button>
        ) : (
          <button
            onClick={onPause}
            className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-200 border-2 border-black pixel-button flex items-center justify-center gap-2"
          >
            <Pause className="w-3.5 h-3.5 fill-slate-200" />
            <span>PAUSE</span>
          </button>
        )}
      </div>

      {/* Footer hint */}
      <div className="text-[10px] text-slate-400 font-silkscreen z-10 flex items-center gap-1">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
        <span>3 Allowed Apps Unlocked (Phone, WhatsApp, Messages)</span>
      </div>
    </div>
  );
};

