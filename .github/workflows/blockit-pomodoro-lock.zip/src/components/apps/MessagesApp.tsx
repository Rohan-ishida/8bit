import React, { useState } from 'react';
import { 
  MessageCircle, 
  Send, 
  Search, 
  ArrowLeft, 
  Sparkles, 
  Zap, 
  CheckCheck, 
  ShieldCheck,
  User
} from 'lucide-react';
import { Contact, ChatMessage } from '../../types';

interface MessagesAppProps {
  contacts: Contact[];
  chats: Record<string, ChatMessage[]>;
  onSendMessage: (contactId: string, text: string) => void;
}

export const MessagesApp: React.FC<MessagesAppProps> = ({
  contacts,
  chats,
  onSendMessage,
}) => {
  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [autoResponderActive, setAutoResponderActive] = useState(true);

  const selectedContact = contacts.find(c => c.id === selectedContactId);
  const currentMessages = selectedContactId ? (chats[selectedContactId] || []) : [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !selectedContactId) return;

    onSendMessage(selectedContactId, inputText.trim());
    setInputText('');
  };

  return (
    <div className="w-full bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col h-[580px] max-w-md mx-auto relative">
      {/* Messages App Header */}
      <div className="bg-indigo-950 px-4 py-3 border-b border-indigo-800/80 flex items-center justify-between text-white">
        <div className="flex items-center gap-2">
          {selectedContactId ? (
            <button
              onClick={() => setSelectedContactId(null)}
              className="p-1 rounded-full hover:bg-indigo-800 text-white cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : (
            <MessageCircle className="w-5 h-5 text-indigo-400" />
          )}

          <div>
            <h3 className="font-bold text-sm leading-tight">
              {selectedContact ? selectedContact.name : 'Messages SMS'}
            </h3>
            <p className="text-[10px] text-indigo-300">
              {selectedContact ? selectedContact.phone : 'Allowed System App'}
            </p>
          </div>
        </div>

        <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30">
          Permitted App
        </span>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto bg-slate-900/50 p-3 space-y-3">
        {!selectedContactId ? (
          /* SMS THREAD LIST */
          <div className="space-y-3">
            {/* Auto Responder Banner */}
            <div className="bg-indigo-900/40 p-3.5 rounded-2xl border border-indigo-800/50 flex items-center justify-between">
              <div className="space-y-0.5 max-w-[220px]">
                <div className="font-semibold text-indigo-200 text-xs flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>Pomodoro Auto-Responder</span>
                </div>
                <p className="text-[10px] text-indigo-300/80">
                  Auto-replies to incoming SMS while in deep focus
                </p>
              </div>

              <button
                onClick={() => setAutoResponderActive(!autoResponderActive)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  autoResponderActive 
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30' 
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {autoResponderActive ? 'ON' : 'OFF'}
              </button>
            </div>

            {/* Messages Thread Items */}
            <div className="space-y-2">
              {contacts.map(contact => {
                const msgs = chats[contact.id] || [];
                const lastMsg = msgs[msgs.length - 1];

                return (
                  <div
                    key={contact.id}
                    onClick={() => setSelectedContactId(contact.id)}
                    className="bg-slate-900 hover:bg-slate-800 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full ${contact.avatarColor} text-white font-bold text-sm flex items-center justify-center shrink-0`}>
                        {contact.name.charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-semibold text-slate-100 text-xs truncate">{contact.name}</span>
                          <span className="text-[10px] text-slate-500">{lastMsg?.timestamp || 'SMS'}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate">
                          {lastMsg ? lastMsg.text : 'Tap to compose SMS message'}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* SMS CONVERSATION VIEW */
          <div className="flex flex-col h-full justify-between space-y-3">
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              {currentMessages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[82%] p-3 rounded-2xl text-xs space-y-1 ${
                    msg.sender === 'user'
                      ? 'bg-indigo-600 text-white rounded-br-none'
                      : 'bg-slate-800 text-slate-200 rounded-bl-none border border-slate-700'
                  }`}>
                    <p className="leading-relaxed">{msg.text}</p>
                    <div className="text-[9px] text-indigo-200/80 text-right">{msg.timestamp}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Input form */}
            <form onSubmit={handleSend} className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <input
                type="text"
                placeholder="Text SMS message..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-700 rounded-full px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="w-10 h-10 rounded-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white flex items-center justify-center transition-all cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
