import React, { useState } from 'react';
import { 
  MessageSquareText, 
  Search, 
  Send, 
  ArrowLeft, 
  Phone, 
  Video, 
  MoreVertical, 
  CheckCheck, 
  Bot, 
  ExternalLink,
  Mic,
  Smile,
  ShieldCheck
} from 'lucide-react';
import { Contact, ChatMessage } from '../../types';

interface WhatsAppAppProps {
  contacts: Contact[];
  chats: Record<string, ChatMessage[]>;
  onSendMessage: (contactId: string, text: string) => void;
  onMakeCall: (contactName: string, phone: string) => void;
}

export const WhatsAppApp: React.FC<WhatsAppAppProps> = ({
  contacts,
  chats,
  onSendMessage,
  onMakeCall,
}) => {
  const [selectedContactId, setSelectedContactId] = useState<string | null>(null);
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const selectedContact = contacts.find(c => c.id === selectedContactId);
  const currentMessages = selectedContactId ? (chats[selectedContactId] || []) : [];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !selectedContactId) return;

    onSendMessage(selectedContactId, inputText.trim());
    setInputText('');
  };

  const handleInsertFocusAutoReply = () => {
    setInputText("🔒 [BlockIt Focus Mode] I am currently in a deep Pomodoro work session. I'll read and respond as soon as my break starts!");
  };

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.status.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full bg-slate-950 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col h-[580px] max-w-md mx-auto relative">
      {/* WhatsApp Header Bar */}
      <div className="bg-teal-900 px-4 py-3 border-b border-teal-800/80 flex items-center justify-between text-white">
        <div className="flex items-center gap-2">
          {selectedContactId ? (
            <button
              onClick={() => setSelectedContactId(null)}
              className="p-1 rounded-full hover:bg-teal-800 text-white cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : (
            <MessageSquareText className="w-5 h-5 text-teal-300" />
          )}

          <div>
            <h3 className="font-bold text-sm leading-tight">
              {selectedContact ? selectedContact.name : 'WhatsApp Focus'}
            </h3>
            <p className="text-[10px] text-teal-200">
              {selectedContact ? (selectedContact.status || 'Online') : 'Allowed Messaging App'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {selectedContact && (
            <button
              onClick={() => onMakeCall(selectedContact.name, selectedContact.phone)}
              className="p-1.5 rounded-lg hover:bg-teal-800 text-teal-100 transition-colors cursor-pointer"
              title="Call Contact"
            >
              <Phone className="w-4 h-4" />
            </button>
          )}

          <a
            href="https://web.whatsapp.com"
            target="_blank"
            rel="noopener noreferrer"
            className="p-1.5 rounded-lg bg-teal-800/80 hover:bg-teal-800 text-teal-200 text-[10px] font-semibold flex items-center gap-1 transition-colors"
            title="Open WhatsApp Web"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Web</span>
          </a>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto bg-slate-900/60 p-3 space-y-3">
        {!selectedContactId ? (
          /* CHAT LIST VIEW */
          <div className="space-y-3">
            {/* Search Box */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search WhatsApp chats..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            {/* Auto-Responder Notice */}
            <div className="bg-teal-950/40 p-3 rounded-xl border border-teal-800/50 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
              <p className="text-[11px] text-teal-200 leading-snug">
                WhatsApp is unlocked for communication during your Pomodoro lock session. Tap a chat to send messages or use the auto-responder template.
              </p>
            </div>

            {/* Chats Listing */}
            <div className="space-y-2">
              {filteredContacts.map(contact => {
                const msgs = chats[contact.id] || [];
                const lastMsg = msgs[msgs.length - 1];

                return (
                  <div
                    key={contact.id}
                    onClick={() => setSelectedContactId(contact.id)}
                    className="bg-slate-900/80 hover:bg-slate-800/80 p-3 rounded-2xl border border-slate-800 flex items-center justify-between cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full ${contact.avatarColor} text-white font-bold text-sm flex items-center justify-center shrink-0`}>
                        {contact.name.charAt(0)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-semibold text-slate-100 text-xs truncate">{contact.name}</span>
                          <span className="text-[10px] text-slate-400 shrink-0">{lastMsg?.timestamp || '10:00 AM'}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate">
                          {lastMsg ? lastMsg.text : contact.status}
                        </p>
                      </div>
                    </div>

                    {contact.unreadCount ? (
                      <span className="ml-2 w-5 h-5 rounded-full bg-teal-500 text-slate-950 font-bold text-[10px] flex items-center justify-center shrink-0">
                        {contact.unreadCount}
                      </span>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* CONVERSATION THREAD VIEW */
          <div className="flex flex-col h-full justify-between space-y-3">
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
              <div className="text-center my-2">
                <span className="text-[10px] bg-slate-800 text-slate-400 px-3 py-1 rounded-full border border-slate-700">
                  🔒 Messages end-to-end encrypted • Pomodoro Mode
                </span>
              </div>

              {currentMessages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[82%] p-3 rounded-2xl text-xs space-y-1 shadow-sm ${
                    msg.sender === 'user'
                      ? 'bg-teal-800 text-teal-50 rounded-br-none'
                      : 'bg-slate-800 text-slate-100 rounded-bl-none border border-slate-700'
                  }`}>
                    {msg.isAutoReply && (
                      <div className="text-[9px] uppercase font-bold text-teal-300 flex items-center gap-1 mb-0.5">
                        <Bot className="w-3 h-3" /> Auto-Responder
                      </div>
                    )}
                    <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                    <div className="flex items-center justify-end gap-1 text-[9px] text-teal-200/70">
                      <span>{msg.timestamp}</span>
                      {msg.sender === 'user' && <CheckCheck className="w-3 h-3 text-teal-300" />}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Auto-Reply Template Bar */}
            <div className="pt-2 border-t border-slate-800 space-y-2">
              <button
                type="button"
                onClick={handleInsertFocusAutoReply}
                className="w-full text-left p-2 rounded-xl bg-teal-950/60 hover:bg-teal-900/60 border border-teal-800/80 text-[11px] text-teal-300 font-medium flex items-center justify-between transition-colors cursor-pointer"
              >
                <span className="truncate">Insert Focus Session Auto-Reply</span>
                <Bot className="w-3.5 h-3.5 shrink-0 ml-1 text-teal-400" />
              </button>

              {/* Message Input Box */}
              <form onSubmit={handleSend} className="flex items-center gap-2">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    placeholder="Type WhatsApp message..."
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-full pl-4 pr-9 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  />
                  <Smile className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
                </div>

                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="w-10 h-10 rounded-full bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white flex items-center justify-center transition-all cursor-pointer shrink-0"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
