import React, { useState } from 'react';
import { 
  Phone, 
  PhoneCall, 
  PhoneOff, 
  User, 
  Clock, 
  Star, 
  Delete, 
  Search, 
  AlertCircle,
  Volume2,
  Mic,
  MicOff,
  UserPlus
} from 'lucide-react';
import { Contact, CallLog } from '../../types';
import { playKeypadTone } from '../../utils/audio';

interface PhoneAppProps {
  contacts: Contact[];
  callLogs: CallLog[];
  onMakeCall: (contactName: string, phone: string) => void;
  onAddContact: (contact: Contact) => void;
}

export const PhoneApp: React.FC<PhoneAppProps> = ({
  contacts,
  callLogs,
  onMakeCall,
  onAddContact,
}) => {
  const [activeTab, setActiveTab] = useState<'keypad' | 'contacts' | 'recents'>('keypad');
  const [dialedNumber, setDialedNumber] = useState('');
  const [activeCall, setActiveCall] = useState<{ name: string; phone: string; duration: number } | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddContactModal, setShowAddContactModal] = useState(false);
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');

  // Call timer effect
  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (activeCall) {
      timer = setInterval(() => {
        setActiveCall(prev => prev ? { ...prev, duration: prev.duration + 1 } : null);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [activeCall]);

  const handleKeyPress = (digit: string, freq1 = 697, freq2 = 1209) => {
    playKeypadTone(freq1, freq2);
    setDialedNumber(prev => prev + digit);
  };

  const handleBackspace = () => {
    setDialedNumber(prev => prev.slice(0, -1));
  };

  const startCall = (name: string, phone: string) => {
    setActiveCall({ name, phone, duration: 0 });
    onMakeCall(name, phone);
  };

  const endCall = () => {
    setActiveCall(null);
  };

  const handleCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim() || !newContactPhone.trim()) return;

    const newContact: Contact = {
      id: `c_${Date.now()}`,
      name: newContactName.trim(),
      phone: newContactPhone.trim(),
      avatarColor: 'bg-emerald-600',
      status: 'Available',
      isEmergencyContact: false,
    };

    onAddContact(newContact);
    setShowAddContactModal(false);
    setNewContactName('');
    setNewContactPhone('');
  };

  const filteredContacts = contacts.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.phone.includes(searchQuery)
  );

  return (
    <div className="w-full bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col h-[580px] max-w-md mx-auto relative">
      {/* Phone Header */}
      <div className="bg-slate-950 px-5 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
          <Phone className="w-4 h-4 fill-emerald-400/20" />
          <span>Phone</span>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
          Allowed App
        </span>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* KEYPAD TAB */}
        {activeTab === 'keypad' && (
          <div className="h-full flex flex-col justify-between max-w-xs mx-auto">
            {/* Number Display */}
            <div className="text-center py-4 min-h-[70px] flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold text-white tracking-widest font-mono">
                {dialedNumber || ' '}
              </span>
              {dialedNumber && (
                <span className="text-xs text-slate-400 mt-1">
                  {contacts.find(c => c.phone.replace(/\D/g, '') === dialedNumber.replace(/\D/g, ''))?.name || 'Unknown Contact'}
                </span>
              )}
            </div>

            {/* Keypad Grid */}
            <div className="grid grid-cols-3 gap-3 my-auto">
              {[
                { digit: '1', letters: '', f1: 697, f2: 1209 },
                { digit: '2', letters: 'ABC', f1: 697, f2: 1336 },
                { digit: '3', letters: 'DEF', f1: 697, f2: 1477 },
                { digit: '4', letters: 'GHI', f1: 770, f2: 1209 },
                { digit: '5', letters: 'JKL', f1: 770, f2: 1336 },
                { digit: '6', letters: 'MNO', f1: 770, f2: 1477 },
                { digit: '7', letters: 'PQRS', f1: 852, f2: 1209 },
                { digit: '8', letters: 'TUV', f1: 852, f2: 1336 },
                { digit: '9', letters: 'WXYZ', f1: 852, f2: 1477 },
                { digit: '*', letters: '', f1: 941, f2: 1209 },
                { digit: '0', letters: '+', f1: 941, f2: 1336 },
                { digit: '#', letters: '', f1: 941, f2: 1477 },
              ].map(key => (
                <button
                  key={key.digit}
                  onClick={() => handleKeyPress(key.digit, key.f1, key.f2)}
                  className="w-16 h-16 rounded-full bg-slate-800/90 hover:bg-slate-700 text-white flex flex-col items-center justify-center border border-slate-700/60 shadow-md active:scale-95 transition-all mx-auto cursor-pointer"
                >
                  <span className="text-xl font-bold">{key.digit}</span>
                  {key.letters && <span className="text-[9px] text-slate-400 font-medium tracking-wider">{key.letters}</span>}
                </button>
              ))}
            </div>

            {/* Call Action Row */}
            <div className="flex items-center justify-center gap-6 pt-2 pb-2">
              <div className="w-12 h-12" /> {/* spacer */}

              <button
                onClick={() => startCall(
                  contacts.find(c => c.phone.replace(/\D/g, '') === dialedNumber.replace(/\D/g, ''))?.name || dialedNumber || 'Emergency Line',
                  dialedNumber || '911'
                )}
                className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/30 active:scale-95 transition-all cursor-pointer"
              >
                <PhoneCall className="w-7 h-7 fill-white" />
              </button>

              {dialedNumber ? (
                <button
                  onClick={handleBackspace}
                  className="w-12 h-12 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer"
                >
                  <Delete className="w-5 h-5" />
                </button>
              ) : (
                <div className="w-12 h-12" />
              )}
            </div>
          </div>
        )}

        {/* CONTACTS TAB */}
        {activeTab === 'contacts' && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search contacts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
              </div>
              <button
                onClick={() => setShowAddContactModal(true)}
                className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                title="Add New Contact"
              >
                <UserPlus className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              {filteredContacts.map(contact => (
                <div
                  key={contact.id}
                  className="bg-slate-800/60 hover:bg-slate-800 p-3 rounded-2xl border border-slate-700/50 flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full ${contact.avatarColor} flex items-center justify-center text-white font-bold text-sm shadow-md`}>
                      {contact.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-slate-100 text-xs">{contact.name}</span>
                        {contact.isEmergencyContact && (
                          <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 text-[9px] font-bold border border-rose-500/30">
                            Emergency
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400">{contact.phone}</div>
                    </div>
                  </div>

                  <button
                    onClick={() => startCall(contact.name, contact.phone)}
                    className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-white transition-all cursor-pointer"
                  >
                    <Phone className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* CALL LOGS / RECENTS TAB */}
        {activeTab === 'recents' && (
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Recent Calls</h4>
            {callLogs.map(log => (
              <div
                key={log.id}
                className="bg-slate-800/60 p-3 rounded-2xl border border-slate-700/50 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                    log.type === 'missed' ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'
                  }`}>
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-100 text-xs">{log.contactName}</div>
                    <div className="text-[10px] text-slate-400 flex items-center gap-2">
                      <span className={log.type === 'missed' ? 'text-rose-400 font-medium' : 'text-slate-400'}>
                        {log.type === 'missed' ? 'Missed Call' : log.type === 'incoming' ? 'Incoming' : 'Outgoing'}
                      </span>
                      <span>•</span>
                      <span>{log.timestamp}</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => startCall(log.contactName, log.phone)}
                  className="p-2 rounded-xl bg-slate-700/80 hover:bg-emerald-500 hover:text-white text-slate-300 transition-all cursor-pointer"
                >
                  <Phone className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Navigation Tabs */}
      <div className="bg-slate-950 border-t border-slate-800 grid grid-cols-3 p-2">
        <button
          onClick={() => setActiveTab('keypad')}
          className={`flex flex-col items-center justify-center py-1.5 text-[10px] font-medium transition-colors ${
            activeTab === 'keypad' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Phone className="w-4 h-4 mb-0.5" />
          <span>Keypad</span>
        </button>

        <button
          onClick={() => setActiveTab('contacts')}
          className={`flex flex-col items-center justify-center py-1.5 text-[10px] font-medium transition-colors ${
            activeTab === 'contacts' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <User className="w-4 h-4 mb-0.5" />
          <span>Contacts</span>
        </button>

        <button
          onClick={() => setActiveTab('recents')}
          className={`flex flex-col items-center justify-center py-1.5 text-[10px] font-medium transition-colors ${
            activeTab === 'recents' ? 'text-emerald-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Clock className="w-4 h-4 mb-0.5" />
          <span>Recents</span>
        </button>
      </div>

      {/* Active Call Simulator Overlay */}
      {activeCall && (
        <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-xl z-50 flex flex-col items-center justify-between p-8 text-center animate-fade-in">
          <div className="space-y-3 mt-8">
            <div className="w-24 h-24 rounded-full bg-emerald-500/20 border-2 border-emerald-500/40 text-emerald-300 mx-auto flex items-center justify-center text-3xl font-extrabold shadow-2xl animate-pulse">
              {activeCall.name.charAt(0)}
            </div>
            <h3 className="text-xl font-bold text-white">{activeCall.name}</h3>
            <p className="text-xs text-emerald-400 font-mono">
              {Math.floor(activeCall.duration / 60)}:{(activeCall.duration % 60).toString().padStart(2, '0')}
            </p>
            <p className="text-[11px] text-slate-400">Emergency & Permitted Voice Line</p>
          </div>

          <div className="w-full space-y-6 mb-4">
            <div className="flex items-center justify-center gap-6">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-4 rounded-full border ${isMuted ? 'bg-rose-500/20 text-rose-400 border-rose-500/40' : 'bg-slate-800 text-slate-200 border-slate-700'}`}
              >
                {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
              </button>
              <button className="p-4 rounded-full bg-slate-800 text-slate-200 border border-slate-700">
                <Volume2 className="w-6 h-6" />
              </button>
            </div>

            <button
              onClick={endCall}
              className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-xl shadow-rose-600/40 mx-auto active:scale-95 transition-all cursor-pointer"
            >
              <PhoneOff className="w-7 h-7" />
            </button>
          </div>
        </div>
      )}

      {/* Modal: Add Contact */}
      {showAddContactModal && (
        <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md z-40 flex items-center justify-center p-4">
          <form onSubmit={handleCreateContact} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 w-full max-w-xs space-y-4 shadow-2xl">
            <h3 className="font-bold text-slate-100 text-sm">Add Allowed Contact</h3>
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Full Name"
                value={newContactName}
                onChange={(e) => setNewContactName(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              />
              <input
                type="tel"
                placeholder="Phone Number"
                value={newContactPhone}
                onChange={(e) => setNewContactPhone(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowAddContactModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-emerald-600 text-white text-xs font-semibold cursor-pointer"
              >
                Save
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
