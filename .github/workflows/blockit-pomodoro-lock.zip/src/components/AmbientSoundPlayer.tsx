import React from 'react';
import { Radio, Volume2, X, CloudRain, Wind, Waves, Coffee, VolumeX } from 'lucide-react';
import { AmbientSoundType } from '../types';

interface AmbientSoundPlayerProps {
  currentSound: AmbientSoundType;
  onSelectSound: (sound: AmbientSoundType) => void;
  onClose: () => void;
}

export const AmbientSoundPlayer: React.FC<AmbientSoundPlayerProps> = ({
  currentSound,
  onSelectSound,
  onClose,
}) => {
  const SOUND_OPTIONS: { id: AmbientSoundType; name: string; desc: string; icon: React.ReactNode }[] = [
    { id: 'none', name: 'MUTE SOUND', desc: 'No background audio generator', icon: <VolumeX className="w-4 h-4 text-slate-400" /> },
    { id: 'rain', name: '8-BIT RAIN NOISE', desc: 'Synthesized rain frequency', icon: <CloudRain className="w-4 h-4 text-blue-400" /> },
    { id: 'white-noise', name: 'WHITE NOISE SYNTH', desc: 'Crisp square wave static filter', icon: <Wind className="w-4 h-4 text-teal-400" /> },
    { id: 'brown-noise', name: 'BROWN NOISE RUMBLE', desc: 'Warm low frequency rumble', icon: <Radio className="w-4 h-4 text-amber-400" /> },
    { id: 'waves', name: 'OCEAN TIDE WAVS', desc: 'Modulated synth ocean tide', icon: <Waves className="w-4 h-4 text-sky-400" /> },
    { id: 'cafe', name: 'RETRO CAFE CHATTER', desc: 'Acoustic background filter', icon: <Coffee className="w-4 h-4 text-rose-400" /> },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 flex items-center justify-center p-4 animate-fade-in font-pixel text-slate-100">
      <div className="bg-slate-900 border-4 border-black pixel-border p-5 max-w-md w-full space-y-4 relative">
        <div className="flex items-center justify-between border-b-2 border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-teal-400" />
            <h3 className="font-pixel text-sm text-teal-400">8-BIT AMBIENT SYNTH</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 bg-slate-800 border-2 border-black pixel-button text-slate-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-[9px] font-silkscreen text-slate-400">
          CHIPTUNE BACKGROUND NOISE GENERATOR FOR MAXIMUM CONCENTRATION.
        </p>

        <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
          {SOUND_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              onClick={() => onSelectSound(opt.id)}
              className={`w-full p-2.5 border-2 border-black flex items-center justify-between transition-all cursor-pointer pixel-button ${
                currentSound === opt.id
                  ? 'bg-teal-950 border-teal-500 text-teal-200'
                  : 'bg-slate-950 border-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-slate-900 border border-slate-800">
                  {opt.icon}
                </div>
                <div className="text-left font-silkscreen">
                  <div className="font-pixel text-[10px] text-white">{opt.name}</div>
                  <div className="text-[8px] text-slate-400">{opt.desc}</div>
                </div>
              </div>

              {currentSound === opt.id && (
                <span className="text-[8px] font-pixel px-1.5 py-0.5 bg-teal-500 text-slate-950 border border-black">
                  ACTIVE
                </span>
              )}
            </button>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-pixel text-xs border-2 border-black pixel-button"
        >
          CLOSE SYNTH
        </button>
      </div>
    </div>
  );
};

