import React from 'react';
import { 
  Timer, 
  Layers, 
  Coffee, 
  Clock, 
  Lock, 
  Unlock, 
  Phone, 
  MessageSquareText, 
  MessageCircle, 
  ShieldAlert, 
  Sparkles,
  Zap,
  CheckCircle2,
  Gamepad2
} from 'lucide-react';
import { PomodoroSettings } from '../types';

interface PomodoroSetupProps {
  settings: PomodoroSettings;
  onUpdateSettings: (settings: PomodoroSettings) => void;
  onStartPomodoro: () => void;
}

export const PomodoroSetup: React.FC<PomodoroSetupProps> = ({
  settings,
  onUpdateSettings,
  onStartPomodoro,
}) => {
  const isLongBreakUnlocked = settings.sessionsCount >= 4;

  const handleSessionsChange = (val: number) => {
    const newCount = Math.max(1, Math.min(12, val));
    onUpdateSettings({
      ...settings,
      sessionsCount: newCount,
    });
  };

  const handleWorkDurationChange = (val: number) => {
    onUpdateSettings({
      ...settings,
      workDuration: Math.max(1, Math.min(120, val)),
    });
  };

  const handleShortBreakChange = (val: number) => {
    onUpdateSettings({
      ...settings,
      shortBreakDuration: Math.max(1, Math.min(30, val)),
    });
  };

  const handleLongBreakChange = (val: number) => {
    onUpdateSettings({
      ...settings,
      longBreakDuration: Math.max(5, Math.min(60, val)),
    });
  };

  // Calculate estimated total focus cycle time
  const totalWorkMins = settings.workDuration * settings.sessionsCount;
  const shortBreaksCount = Math.max(0, settings.sessionsCount - 1);
  const totalBreakMins = isLongBreakUnlocked
    ? (shortBreaksCount - 1) * settings.shortBreakDuration + settings.longBreakDuration
    : shortBreaksCount * settings.shortBreakDuration;
  const grandTotalMins = totalWorkMins + totalBreakMins;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-fade-in pb-12 font-pixel">
      {/* 8-Bit Banner Arcade Box */}
      <div className="bg-slate-900 border-4 border-emerald-500 pixel-border p-5 md:p-6 text-slate-100 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3 max-w-xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 bg-rose-600 text-white border-2 border-black text-[10px]">
              <Gamepad2 className="w-4 h-4" />
              <span>STAGE SELECT • FOCUS MISSION</span>
            </div>
            <h2 className="text-sm sm:text-base md:text-lg font-pixel text-emerald-400 drop-shadow-[2px_2px_0px_#000]">
              8-BIT POMODORO LOCK SETUP
            </h2>
            <p className="text-xs text-slate-300 font-silkscreen leading-relaxed">
              Configure your focus duration. When the 8-bit lock engages, all social/video apps are blocked. Only <strong className="text-emerald-400">Phone</strong>, <strong className="text-emerald-400">WhatsApp</strong>, and <strong className="text-emerald-400">Messages</strong> remain unlocked for communications.
            </p>
          </div>

          <div className="bg-slate-950 p-3 border-2 border-slate-700 text-center min-w-[180px]">
            <span className="text-[10px] text-slate-400 font-silkscreen uppercase">EST. MISSION TIME</span>
            <div className="text-base sm:text-lg font-pixel text-amber-400 mt-1">
              {Math.floor(grandTotalMins / 60)}H {grandTotalMins % 60}M
            </div>
            <span className="text-[9px] text-slate-400 font-silkscreen">
              {settings.sessionsCount} LEVEL{settings.sessionsCount > 1 ? 'S' : ''} ({totalWorkMins}M FOCUS)
            </span>
          </div>
        </div>
      </div>

      {/* Main Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Card 1: Work Time & Sessions Count */}
        <div className="bg-slate-900 p-5 border-4 border-black pixel-border space-y-5">
          <div className="flex items-center justify-between border-b-2 border-slate-800 pb-3">
            <div className="flex items-center gap-2 text-indigo-400 text-xs sm:text-sm">
              <Timer className="w-4 h-4 text-indigo-400" />
              <span>1. WORK DURATION</span>
            </div>
            <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-700 px-2 py-0.5">
              SETTING
            </span>
          </div>

          {/* Work Time Duration */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300 font-silkscreen">FOCUS TIME:</span>
              <span className="text-sm font-pixel text-indigo-400">
                {settings.workDuration} MIN
              </span>
            </div>

            <input
              type="range"
              min="1"
              max="90"
              step="1"
              value={settings.workDuration}
              onChange={(e) => handleWorkDurationChange(Number(e.target.value))}
              className="w-full h-3 bg-slate-950 rounded-none appearance-none cursor-pointer accent-indigo-500 border border-black"
            />

            {/* Quick Presets */}
            <div className="grid grid-cols-4 gap-1.5 text-[10px]">
              {[15, 25, 45, 60].map((mins) => (
                <button
                  key={mins}
                  onClick={() => handleWorkDurationChange(mins)}
                  className={`py-1.5 border-2 border-black pixel-button ${
                    settings.workDuration === mins
                      ? 'bg-indigo-600 text-white font-bold'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {mins}M
                </button>
              ))}
            </div>
          </div>

          {/* Sessions Count */}
          <div className="space-y-3 pt-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300 font-silkscreen">REPETITIONS:</span>
              <span className="text-sm font-pixel text-indigo-400">
                {settings.sessionsCount} SESSIONS
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleSessionsChange(settings.sessionsCount - 1)}
                className="w-8 h-8 bg-slate-800 hover:bg-slate-700 text-white font-pixel border-2 border-black pixel-button text-xs flex items-center justify-center"
              >
                -
              </button>

              <input
                type="range"
                min="1"
                max="12"
                step="1"
                value={settings.sessionsCount}
                onChange={(e) => handleSessionsChange(Number(e.target.value))}
                className="flex-1 h-3 bg-slate-950 rounded-none appearance-none cursor-pointer accent-indigo-500 border border-black"
              />

              <button
                onClick={() => handleSessionsChange(settings.sessionsCount + 1)}
                className="w-8 h-8 bg-slate-800 hover:bg-slate-700 text-white font-pixel border-2 border-black pixel-button text-xs flex items-center justify-center"
              >
                +
              </button>
            </div>

            {/* Quick Session Presets */}
            <div className="grid grid-cols-4 gap-1.5 text-[10px]">
              {[2, 4, 6, 8].map((count) => (
                <button
                  key={count}
                  onClick={() => handleSessionsChange(count)}
                  className={`py-1.5 border-2 border-black pixel-button ${
                    settings.sessionsCount === count
                      ? 'bg-indigo-600 text-white font-bold'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {count}X {count === 4 ? '⭐' : ''}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Card 2: Break Settings (Short & Long) */}
        <div className="bg-slate-900 p-5 border-4 border-black pixel-border space-y-5">
          <div className="flex items-center justify-between border-b-2 border-slate-800 pb-3">
            <div className="flex items-center gap-2 text-teal-400 text-xs sm:text-sm">
              <Coffee className="w-4 h-4 text-teal-400" />
              <span>2. REST BREAKS</span>
            </div>
            <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-700 px-2 py-0.5">
              RECOVERY
            </span>
          </div>

          {/* Short Break */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300 font-silkscreen">SHORT BREAK:</span>
              <span className="text-sm font-pixel text-teal-400">
                {settings.shortBreakDuration} MIN
              </span>
            </div>

            <input
              type="range"
              min="1"
              max="20"
              step="1"
              value={settings.shortBreakDuration}
              onChange={(e) => handleShortBreakChange(Number(e.target.value))}
              className="w-full h-3 bg-slate-950 rounded-none appearance-none cursor-pointer accent-teal-500 border border-black"
            />

            <div className="grid grid-cols-4 gap-1.5 text-[10px]">
              {[3, 5, 10, 15].map((mins) => (
                <button
                  key={mins}
                  onClick={() => handleShortBreakChange(mins)}
                  className={`py-1.5 border-2 border-black pixel-button ${
                    settings.shortBreakDuration === mins
                      ? 'bg-teal-600 text-white font-bold'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {mins}M
                </button>
              ))}
            </div>
          </div>

          {/* Long Break */}
          <div className={`space-y-3 p-3 border-2 border-black ${
            isLongBreakUnlocked
              ? 'bg-slate-950'
              : 'bg-slate-950/60 opacity-80'
          }`}>
            <div className="flex justify-between items-center text-xs">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-300 font-silkscreen">LONG BREAK:</span>
                {isLongBreakUnlocked ? (
                  <span className="text-[9px] bg-emerald-600 text-white px-1.5 py-0.5 border border-black">
                    UNLOCKED
                  </span>
                ) : (
                  <span className="text-[9px] bg-amber-600 text-white px-1.5 py-0.5 border border-black">
                    LOCKED (NEED 4+ SESSIONS)
                  </span>
                )}
              </div>

              {isLongBreakUnlocked && (
                <span className="text-sm font-pixel text-teal-400">
                  {settings.longBreakDuration} MIN
                </span>
              )}
            </div>

            {isLongBreakUnlocked ? (
              <>
                <input
                  type="range"
                  min="5"
                  max="60"
                  step="5"
                  value={settings.longBreakDuration}
                  onChange={(e) => handleLongBreakChange(Number(e.target.value))}
                  className="w-full h-3 bg-slate-900 rounded-none appearance-none cursor-pointer accent-teal-500 border border-black"
                />

                <div className="grid grid-cols-4 gap-1.5 text-[10px]">
                  {[15, 20, 30, 45].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => handleLongBreakChange(mins)}
                      className={`py-1.5 border-2 border-black pixel-button ${
                        settings.longBreakDuration === mins
                          ? 'bg-teal-600 text-white font-bold'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                      }`}
                    >
                      {mins}M
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-[10px] text-amber-300 font-silkscreen leading-relaxed">
                Set session target to 4 or more above to unlock long break reward!
              </p>
            )}
          </div>
        </div>

      </div>

      {/* Allowed Apps Preview */}
      <div className="bg-slate-900 p-5 border-4 border-black pixel-border space-y-3">
        <div className="flex items-center justify-between border-b-2 border-slate-800 pb-2 text-xs">
          <div className="flex items-center gap-2 text-emerald-400">
            <ShieldAlert className="w-4 h-4" />
            <span>UNLOCKED APPS DURING FOCUS MODE</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-silkscreen">
            STRICT 3-APP OS
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          {/* App 1: Phone */}
          <div className="bg-slate-950 p-3 border-2 border-emerald-600/60 flex items-center gap-3">
            <div className="w-8 h-8 bg-emerald-500 text-slate-950 font-pixel text-xs border border-black flex items-center justify-center">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <div className="font-pixel text-xs text-white">1. PHONE</div>
              <div className="text-[10px] text-slate-400 font-silkscreen">Emergency Dialer</div>
            </div>
          </div>

          {/* App 2: WhatsApp */}
          <div className="bg-slate-950 p-3 border-2 border-emerald-600/60 flex items-center gap-3">
            <div className="w-8 h-8 bg-teal-500 text-slate-950 font-pixel text-xs border border-black flex items-center justify-center">
              <MessageSquareText className="w-4 h-4" />
            </div>
            <div>
              <div className="font-pixel text-xs text-white">2. WHATSAPP</div>
              <div className="text-[10px] text-slate-400 font-silkscreen">Direct Messaging</div>
            </div>
          </div>

          {/* App 3: Messages */}
          <div className="bg-slate-950 p-3 border-2 border-emerald-600/60 flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-500 text-slate-950 font-pixel text-xs border border-black flex items-center justify-center">
              <MessageCircle className="w-4 h-4" />
            </div>
            <div>
              <div className="font-pixel text-xs text-white">3. MESSAGES</div>
              <div className="text-[10px] text-slate-400 font-silkscreen">SMS & Auto-Reply</div>
            </div>
          </div>
        </div>
      </div>

      {/* Start Mission Button */}
      <div className="pt-2 text-center">
        <button
          onClick={onStartPomodoro}
          className="w-full max-w-xl mx-auto py-4 px-6 bg-rose-600 hover:bg-rose-500 text-white font-pixel text-xs sm:text-sm tracking-wider border-4 border-black pixel-button flex items-center justify-center gap-3"
        >
          <Lock className="w-5 h-5 text-amber-300" />
          <span>START 8-BIT LOCK ({settings.workDuration}M)</span>
          <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
        </button>
        <p className="text-[10px] text-slate-500 font-silkscreen mt-2">
          Pressing START locks down distractions & opens 8-Bit Focus Launcher.
        </p>
      </div>
    </div>
  );
};

