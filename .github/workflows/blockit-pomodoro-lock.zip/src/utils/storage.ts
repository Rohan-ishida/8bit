import { AppInfo, Contact, ChatMessage, CallLog, PomodoroSettings, FocusSessionRecord, DayStreak, BlockedAttempt } from '../types';

export const STORAGE_KEYS = {
  SETTINGS: 'blockit_settings_v1',
  CONTACTS: 'blockit_contacts_v1',
  CHATS: 'blockit_chats_v1',
  CALL_LOGS: 'blockit_call_logs_v1',
  SESSIONS: 'blockit_sessions_v1',
  STREAK: 'blockit_streak_v1',
  BLOCKED_ATTEMPTS: 'blockit_blocked_attempts_v1',
};

export const DEFAULT_SETTINGS: PomodoroSettings = {
  workDuration: 25,
  sessionsCount: 4,
  shortBreakDuration: 5,
  longBreakDuration: 15,
  soundEnabled: true,
  ambientSound: 'none',
  autoStartBreaks: false,
  autoStartPomodoros: false,
  strictLockMode: true,
};

export const ALL_APPS: AppInfo[] = [
  { id: 'phone', name: 'Phone', category: 'Communication', iconName: 'Phone', isAllowed: true, blockedCount: 0 },
  { id: 'whatsapp', name: 'WhatsApp', category: 'Social', iconName: 'MessageSquareText', isAllowed: true, blockedCount: 0 },
  { id: 'messages', name: 'Messages', category: 'System SMS', iconName: 'MessageCircle', isAllowed: true, blockedCount: 0 },
  { id: 'instagram', name: 'Instagram', category: 'Social Media', iconName: 'Instagram', isAllowed: false, blockedCount: 0 },
  { id: 'youtube', name: 'YouTube', category: 'Video Stream', iconName: 'Youtube', isAllowed: false, blockedCount: 0 },
  { id: 'tiktok', name: 'TikTok', category: 'Short Videos', iconName: 'Video', isAllowed: false, blockedCount: 0 },
  { id: 'chrome', name: 'Browser', category: 'Web', iconName: 'Globe', isAllowed: false, blockedCount: 0 },
  { id: 'twitter', name: 'X / Twitter', category: 'News & Social', iconName: 'Twitter', isAllowed: false, blockedCount: 0 },
  { id: 'games', name: 'Games', category: 'Entertainment', iconName: 'Gamepad2', isAllowed: false, blockedCount: 0 },
];

export const DEFAULT_CONTACTS: Contact[] = [
  {
    id: 'c1',
    name: 'Mom',
    phone: '+1 (555) 019-2831',
    avatarColor: 'bg-emerald-500',
    status: 'Call me for emergencies only ❤️',
    unreadCount: 1,
    lastSeen: '10 mins ago',
    isEmergencyContact: true,
  },
  {
    id: 'c2',
    name: 'Dad',
    phone: '+1 (555) 014-8832',
    avatarColor: 'bg-blue-500',
    status: 'At work',
    unreadCount: 0,
    lastSeen: '2 hours ago',
    isEmergencyContact: true,
  },
  {
    id: 'c3',
    name: 'Project Manager (Boss)',
    phone: '+1 (555) 017-9944',
    avatarColor: 'bg-purple-500',
    status: 'Busy - In meetings',
    unreadCount: 2,
    lastSeen: 'Just now',
    isEmergencyContact: false,
  },
  {
    id: 'c4',
    name: 'Dr. Sarah (Clinic)',
    phone: '+1 (555) 012-3311',
    avatarColor: 'bg-teal-500',
    status: 'Available',
    unreadCount: 0,
    lastSeen: 'Yesterday',
    isEmergencyContact: true,
  },
  {
    id: 'c5',
    name: 'Alex (Study Buddy)',
    phone: '+1 (555) 018-7722',
    avatarColor: 'bg-amber-500',
    status: 'Focusing on Pomodoro 🍅',
    unreadCount: 0,
    lastSeen: '1 hour ago',
    isEmergencyContact: false,
  },
];

export const INITIAL_CHATS: Record<string, ChatMessage[]> = {
  c1: [
    {
      id: 'm1',
      contactId: 'c1',
      text: 'Hey sweetheart! Make sure to take breaks while studying!',
      timestamp: '10:15 AM',
      sender: 'contact',
    },
    {
      id: 'm2',
      contactId: 'c1',
      text: 'Thanks Mom! I activated BlockIt Pomodoro lock mode right now.',
      timestamp: '10:16 AM',
      sender: 'user',
    },
  ],
  c3: [
    {
      id: 'm3',
      contactId: 'c3',
      text: 'Hi, please send over the latest status report when you finish your focus sprint.',
      timestamp: '09:45 AM',
      sender: 'contact',
    },
    {
      id: 'm4',
      contactId: 'c3',
      text: '[Auto-Reply] I am currently in a strict Pomodoro focus session. I will respond as soon as my timer ends.',
      timestamp: '09:46 AM',
      sender: 'user',
      isAutoReply: true,
    },
  ],
};

export const INITIAL_CALL_LOGS: CallLog[] = [
  {
    id: 'l1',
    contactName: 'Mom',
    phone: '+1 (555) 019-2831',
    timestamp: 'Today, 10:14 AM',
    type: 'incoming',
    duration: '2 mins 14 secs',
  },
  {
    id: 'l2',
    contactName: 'Project Manager (Boss)',
    phone: '+1 (555) 017-9944',
    timestamp: 'Today, 09:30 AM',
    type: 'missed',
  },
  {
    id: 'l3',
    contactName: 'Dad',
    phone: '+1 (555) 014-8832',
    timestamp: 'Yesterday, 8:20 PM',
    type: 'outgoing',
    duration: '5 mins 40 secs',
  },
];

// Helper Functions for LocalStorage Persistence
export function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch (e) {
    console.warn(`Failed to parse ${key} from storage`, e);
    return fallback;
  }
}

export function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn(`Failed to save ${key} to storage`, e);
  }
}

export function getTodayString(): string {
  const today = new Date();
  return today.toISOString().split('T')[0];
}
