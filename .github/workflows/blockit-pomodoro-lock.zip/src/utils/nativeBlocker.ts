// Utility for Native Android System-Level Blocking (Capacitor / Android Bridge)

export const APP_PACKAGE_MAP: Record<string, string[]> = {
  instagram: ['com.instagram.android'],
  youtube: ['com.google.android.youtube', 'com.google.android.youtube.tv'],
  tiktok: ['com.zhiliaoapp.musically', 'com.ss.android.ugc.trill'],
  chrome: ['com.android.chrome', 'org.mozilla.firefox', 'com.microsoft.emmx'],
  twitter: ['com.twitter.android', 'com.twitter.android.lite'],
  games: ['com.kiloo.subwaysurf', 'com.king.candycrushsaga', 'com.pubg.krmobile', 'com.epicgames.fortnite'],
};

export const ALLOWED_PACKAGES = [
  'com.android.dialer',
  'com.samsung.android.dialer',
  'com.google.android.dialer',
  'com.whatsapp',
  'com.whatsapp.w4b',
  'com.google.android.apps.messaging',
  'com.samsung.android.messaging'
];

interface NativeBlockerPlugin {
  startBlocking: (options: { blockedPackages: string[]; allowedPackages: string[] }) => Promise<{ success: boolean }>;
  stopBlocking: () => Promise<{ success: boolean }>;
  requestPermissions: () => Promise<{ usageStatsGranted: boolean; overlayGranted: boolean }>;
  checkPermissions: () => Promise<{ usageStatsGranted: boolean; overlayGranted: boolean }>;
}

declare global {
  interface Window {
    Capacitor?: {
      isNativePlatform?: () => boolean;
      getPlatform?: () => string;
      Plugins?: {
        AppBlocker?: NativeBlockerPlugin;
      };
    };
  }
}

export const isNativeAndroid = (): boolean => {
  return typeof window !== 'undefined' && 
    !!window.Capacitor?.isNativePlatform && 
    window.Capacitor.isNativePlatform() &&
    window.Capacitor.getPlatform?.() === 'android';
};

export const startNativeBlocking = async (blockedAppIds: string[]): Promise<boolean> => {
  if (!isNativeAndroid() || !window.Capacitor?.Plugins?.AppBlocker) {
    console.log('[NativeBlocker] Running in web mode. Native system-level blocking requires Capacitor Android APK.');
    return false;
  }

  try {
    const blockedPackages: string[] = [];
    blockedAppIds.forEach(id => {
      if (APP_PACKAGE_MAP[id]) {
        blockedPackages.push(...APP_PACKAGE_MAP[id]);
      }
    });

    const res = await window.Capacitor.Plugins.AppBlocker.startBlocking({
      blockedPackages,
      allowedPackages: ALLOWED_PACKAGES
    });
    return res.success;
  } catch (err) {
    console.warn('[NativeBlocker] Failed to start native blocker service:', err);
    return false;
  }
};

export const stopNativeBlocking = async (): Promise<boolean> => {
  if (!isNativeAndroid() || !window.Capacitor?.Plugins?.AppBlocker) {
    return false;
  }

  try {
    const res = await window.Capacitor.Plugins.AppBlocker.stopBlocking();
    return res.success;
  } catch (err) {
    console.warn('[NativeBlocker] Failed to stop native blocker service:', err);
    return false;
  }
};

export const requestNativePermissions = async (): Promise<{ usageStatsGranted: boolean; overlayGranted: boolean }> => {
  if (!isNativeAndroid() || !window.Capacitor?.Plugins?.AppBlocker) {
    return { usageStatsGranted: false, overlayGranted: false };
  }

  try {
    return await window.Capacitor.Plugins.AppBlocker.requestPermissions();
  } catch (err) {
    console.warn('[NativeBlocker] Permission request failed:', err);
    return { usageStatsGranted: false, overlayGranted: false };
  }
};
