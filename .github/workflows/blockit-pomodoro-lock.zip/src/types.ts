export type TimerPhase = 'idle' | 'work' | 'shortBreak' | 'longBreak' | 'paused' | 'completed';

export type AmbientSoundType = 'none' | 'rain' | 'white-noise' | 'brown-noise' | 'cafe' | 'waves';

export interface PomodoroSettings {
  workDuration: number; // in minutes (1 - 120)
  sessionsCount: number; // target work sessions (1 - 12)
  shortBreakDuration: number; // in minutes (1 - 30)
  longBreakDuration: number; // in minutes (5 - 60), active only if sessionsCount >= 4
  soundEnabled: boolean;
  ambientSound: AmbientSoundType;
  autoStartBreaks: boolean;
  autoStartPomodoros: boolean;
  strictLockMode: boolean; // prevents easy exit during work sessions
}

export type AppId = 
  | 'phone' 
  | 'whatsapp' 
  | 'messages' 
  | 'instagram' 
  | 'youtube' 
  | 'tiktok' 
  | 'chrome' 
  | 'twitter' 
  | 'games';

export interface AppInfo {
  id: AppId;
  name: string;
  category: string;
  iconName: string;
  isAllowed: boolean; // Only phone, whatsapp, messages are allowed during pomodoro
  blockedCount: number;
}

export interface Contact {
  id: string;
  name: string;
  phone: string;
  avatarColor: string;
  status: string;
  unreadCount?: number;
  lastSeen?: string;
  isEmergencyContact?: boolean;
}

export interface ChatMessage {
  id: string;
  contactId: string;
  text: string;
  timestamp: string;
  sender: 'user' | 'contact';
  isAutoReply?: boolean;
}

export interface CallLog {
  id: string;
  contactName: string;
  phone: string;
  timestamp: string;
  type: 'incoming' | 'outgoing' | 'missed';
  duration?: string;
}

export interface BlockedAttempt {
  id: string;
  appId: AppId;
  appName: string;
  timestamp: string;
  phase: TimerPhase;
}

export interface FocusSessionRecord {
  id: string;
  date: string; // YYYY-MM-DD
  completedSessions: number;
  targetSessions: number;
  totalWorkMinutes: number;
  blockedAttemptsCount: number;
}

export interface DayStreak {
  currentStreak: number;
  lastActiveDate: string; // YYYY-MM-DD
  totalSessionsCompleted: number;
}
