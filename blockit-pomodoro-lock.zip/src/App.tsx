import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  PomodoroSettings, 
  TimerPhase, 
  AppInfo, 
  Contact, 
  ChatMessage, 
  CallLog, 
  FocusSessionRecord, 
  DayStreak, 
  BlockedAttempt,
  AmbientSoundType
} from './types';
import { 
  DEFAULT_SETTINGS, 
  ALL_APPS, 
  DEFAULT_CONTACTS, 
  INITIAL_CHATS, 
  INITIAL_CALL_LOGS, 
  loadFromStorage, 
  saveToStorage, 
  STORAGE_KEYS,
  getTodayString
} from './utils/storage';
import { 
  playNotificationTone, 
  startAmbientSound, 
  stopAmbientSound 
} from './utils/audio';

import { Header } from './components/Header';
import { PomodoroSetup } from './components/PomodoroSetup';
import { TimerDisplay } from './components/TimerDisplay';
import { FocusOSLauncher } from './components/FocusOSLauncher';
import { BlockShieldModal } from './components/BlockShieldModal';
import { AmbientSoundPlayer } from './components/AmbientSoundPlayer';
import { StatsModal } from './components/StatsModal';

export default function App() {
  // Load state from local storage with fallbacks
  const [settings, setSettings] = useState<PomodoroSettings>(() => 
    loadFromStorage(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS)
  );

  const [contacts, setContacts] = useState<Contact[]>(() => 
    loadFromStorage(STORAGE_KEYS.CONTACTS, DEFAULT_CONTACTS)
  );

  const [chats, setChats] = useState<Record<string, ChatMessage[]>>(() => 
    loadFromStorage(STORAGE_KEYS.CHATS, INITIAL_CHATS)
  );

  const [callLogs, setCallLogs] = useState<CallLog[]>(() => 
    loadFromStorage(STORAGE_KEYS.CALL_LOGS, INITIAL_CALL_LOGS)
  );

  const [sessionHistory, setSessionHistory] = useState<FocusSessionRecord[]>(() => 
    loadFromStorage(STORAGE_KEYS.SESSIONS, [
      {
        id: 's_prev1',
        date: '2026-07-23',
        completedSessions: 4,
        targetSessions: 4,
        totalWorkMinutes: 100,
        blockedAttemptsCount: 2,
      }
    ])
  );

  const [streak, setStreak] = useState<DayStreak>(() => 
    loadFromStorage(STORAGE_KEYS.STREAK, {
      currentStreak: 3,
      lastActiveDate: getTodayString(),
      totalSessionsCompleted: 12,
    })
  );

  const [blockedAttempts, setBlockedAttempts] = useState<BlockedAttempt[]>(() => 
    loadFromStorage(STORAGE_KEYS.BLOCKED_ATTEMPTS, [])
  );

  // Active Timer state
  const [timerPhase, setTimerPhase] = useState<TimerPhase>('idle');
  const [currentSession, setCurrentSession] = useState<number>(1);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(25 * 60);
  const [totalPhaseSeconds, setTotalPhaseSeconds] = useState<number>(25 * 60);

  // Modals & UI Controls
  const [selectedBlockedApp, setSelectedBlockedApp] = useState<AppInfo | null>(null);
  const [showStatsModal, setShowStatsModal] = useState<boolean>(false);
  const [showAmbientDrawer, setShowAmbientDrawer] = useState<boolean>(false);
  const [isAmbientPlaying, setIsAmbientPlaying] = useState<boolean>(false);

  // Save changes to localStorage
  useEffect(() => saveToStorage(STORAGE_KEYS.SETTINGS, settings), [settings]);
  useEffect(() => saveToStorage(STORAGE_KEYS.CONTACTS, contacts), [contacts]);
  useEffect(() => saveToStorage(STORAGE_KEYS.CHATS, chats), [chats]);
  useEffect(() => saveToStorage(STORAGE_KEYS.CALL_LOGS, callLogs), [callLogs]);
  useEffect(() => saveToStorage(STORAGE_KEYS.SESSIONS, sessionHistory), [sessionHistory]);
  useEffect(() => saveToStorage(STORAGE_KEYS.STREAK, streak), [streak]);
  useEffect(() => saveToStorage(STORAGE_KEYS.BLOCKED_ATTEMPTS, blockedAttempts), [blockedAttempts]);

  // Main Timer Countdown Loop
  useEffect(() => {
    let timerId: NodeJS.Timeout;

    if (timerPhase === 'work' || timerPhase === 'shortBreak' || timerPhase === 'longBreak') {
      timerId = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            handlePhaseComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(timerId);
  }, [timerPhase, secondsRemaining, currentSession, settings]);

  // Handle phase completion transition logic
  const handlePhaseComplete = () => {
    if (settings.soundEnabled) {
      playNotificationTone('completed');
    }

    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }

    if (timerPhase === 'work') {
      // Record completed session
      recordCompletedWorkSession();

      // Check if this was the last session
      if (currentSession >= settings.sessionsCount) {
        // Check long break eligibility (requires 4+ sessions target)
        if (settings.sessionsCount >= 4) {
          const longBreakSecs = settings.longBreakDuration * 60;
          setTimerPhase('longBreak');
          setSecondsRemaining(longBreakSecs);
          setTotalPhaseSeconds(longBreakSecs);
          if (settings.soundEnabled) playNotificationTone('breakStart');
        } else {
          setTimerPhase('completed');
        }
      } else {
        // Transition to Short Break
        const shortBreakSecs = settings.shortBreakDuration * 60;
        setTimerPhase('shortBreak');
        setSecondsRemaining(shortBreakSecs);
        setTotalPhaseSeconds(shortBreakSecs);
        if (settings.soundEnabled) playNotificationTone('breakStart');
      }
    } else if (timerPhase === 'shortBreak' || timerPhase === 'longBreak') {
      // Transition back to Work Focus
      const nextSession = currentSession + 1;
      if (nextSession <= settings.sessionsCount) {
        setCurrentSession(nextSession);
        const workSecs = settings.workDuration * 60;
        setTimerPhase('work');
        setSecondsRemaining(workSecs);
        setTotalPhaseSeconds(workSecs);
        if (settings.soundEnabled) playNotificationTone('workStart');
      } else {
        setTimerPhase('completed');
      }
    }
  };

  // Record completed work stats
  const recordCompletedWorkSession = () => {
    const todayStr = getTodayString();
    
    // Update streak
    setStreak(prev => {
      const isNewDay = prev.lastActiveDate !== todayStr;
      return {
        currentStreak: isNewDay ? prev.currentStreak + 1 : prev.currentStreak,
        lastActiveDate: todayStr,
        totalSessionsCompleted: prev.totalSessionsCompleted + 1,
      };
    });

    // Update Session History
    setSessionHistory(prev => {
      const existingTodayIndex = prev.findIndex(s => s.date === todayStr);
      if (existingTodayIndex >= 0) {
        const updated = [...prev];
        updated[existingTodayIndex] = {
          ...updated[existingTodayIndex],
          completedSessions: updated[existingTodayIndex].completedSessions + 1,
          totalWorkMinutes: updated[existingTodayIndex].totalWorkMinutes + settings.workDuration,
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            id: `s_${Date.now()}`,
            date: todayStr,
            completedSessions: 1,
            targetSessions: settings.sessionsCount,
            totalWorkMinutes: settings.workDuration,
            blockedAttemptsCount: 0,
          },
        ];
      }
    });
  };

  // Start Pomodoro Lock Session
  const handleStartPomodoro = () => {
    const workSecs = settings.workDuration * 60;
    setTimerPhase('work');
    setCurrentSession(1);
    setSecondsRemaining(workSecs);
    setTotalPhaseSeconds(workSecs);

    if (settings.soundEnabled) {
      playNotificationTone('workStart');
    }

    if (settings.ambientSound !== 'none') {
      startAmbientSound(settings.ambientSound);
      setIsAmbientPlaying(true);
    }
  };

  // Pause / Resume / Skip / Stop
  const handlePause = () => {
    setTimerPhase('paused');
  };

  const handleResume = () => {
    setTimerPhase('work');
  };

  const handleSkipPhase = () => {
    handlePhaseComplete();
  };

  // Handle clicking blocked app
  const handleBlockedAppClick = (app: AppInfo) => {
    setSelectedBlockedApp(app);
    if (settings.soundEnabled) {
      playNotificationTone('alert');
    }

    // Log attempt
    const newAttempt: BlockedAttempt = {
      id: `b_${Date.now()}`,
      appId: app.id,
      appName: app.name,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      phase: timerPhase,
    };

    setBlockedAttempts(prev => [newAttempt, ...prev]);
  };

  // Send message handler for allowed apps
  const handleSendMessage = (contactId: string, text: string) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newMsg: ChatMessage = {
      id: `m_${Date.now()}`,
      contactId,
      text,
      timestamp: timeStr,
      sender: 'user',
    };

    setChats(prev => ({
      ...prev,
      [contactId]: [...(prev[contactId] || []), newMsg],
    }));
  };

  // Call handler for allowed phone app
  const handleMakeCall = (contactName: string, phone: string) => {
    const newLog: CallLog = {
      id: `l_${Date.now()}`,
      contactName,
      phone,
      timestamp: 'Just now',
      type: 'outgoing',
      duration: '0 mins 45 secs',
    };

    setCallLogs(prev => [newLog, ...prev]);
  };

  // Add Contact
  const handleAddContact = (newContact: Contact) => {
    setContacts(prev => [...prev, newContact]);
  };

  // Ambient sound selector
  const handleSelectAmbientSound = (sound: AmbientSoundType) => {
    setSettings(prev => ({ ...prev, ambientSound: sound }));
    if (sound === 'none') {
      stopAmbientSound();
      setIsAmbientPlaying(false);
    } else {
      startAmbientSound(sound);
      setIsAmbientPlaying(true);
    }
  };

  const isLockActive = timerPhase === 'work' || timerPhase === 'shortBreak' || timerPhase === 'longBreak' || timerPhase === 'paused';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-rose-500 selection:text-white flex flex-col justify-between antialiased">
      {/* Top App Bar */}
      <Header
        settings={settings}
        onUpdateSettings={setSettings}
        streakDays={streak.currentStreak}
        timerPhase={timerPhase}
        onOpenStats={() => setShowStatsModal(true)}
        onToggleAmbientDrawer={() => setShowAmbientDrawer(true)}
        isAmbientPlaying={isAmbientPlaying}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6 sm:py-8">
        {!isLockActive && timerPhase !== 'completed' ? (
          /* 1. INITIAL APP SETUP SCREEN */
          <PomodoroSetup
            settings={settings}
            onUpdateSettings={setSettings}
            onStartPomodoro={handleStartPomodoro}
          />
        ) : (
          /* 2. ACTIVE POMODORO LOCK SCREEN */
          <div className="space-y-8 animate-fade-in">
            {/* Top Timer Display Card */}
            <TimerDisplay
              phase={timerPhase}
              secondsRemaining={secondsRemaining}
              totalPhaseSeconds={totalPhaseSeconds}
              currentSession={currentSession}
              totalSessions={settings.sessionsCount}
              onPause={handlePause}
              onResume={handleResume}
              onSkip={handleSkipPhase}
            />

            {/* Smartphone Focus OS Launcher (Only 3 Allowed Apps Unlocked) */}
            <FocusOSLauncher
              timerPhase={timerPhase}
              secondsRemaining={secondsRemaining}
              currentSession={currentSession}
              totalSessions={settings.sessionsCount}
              allApps={ALL_APPS}
              contacts={contacts}
              chats={chats}
              callLogs={callLogs}
              onPause={handlePause}
              onResume={handleResume}
              onSkip={handleSkipPhase}
              onBlockedAppClick={handleBlockedAppClick}
              onSendMessage={handleSendMessage}
              onMakeCall={handleMakeCall}
              onAddContact={handleAddContact}
            />
          </div>
        )}
      </main>

      {/* Modals & Overlays */}

      {/* BlockIt Shield Modal */}
      {selectedBlockedApp && (
        <BlockShieldModal
          blockedApp={selectedBlockedApp}
          secondsRemaining={secondsRemaining}
          onClose={() => setSelectedBlockedApp(null)}
        />
      )}

      {/* Ambient Noise Selector Drawer */}
      {showAmbientDrawer && (
        <AmbientSoundPlayer
          currentSound={settings.ambientSound}
          onSelectSound={handleSelectAmbientSound}
          onClose={() => setShowAmbientDrawer(false)}
        />
      )}

      {/* Stats & Analytics Modal */}
      {showStatsModal && (
        <StatsModal
          streak={streak}
          sessionHistory={sessionHistory}
          blockedAttempts={blockedAttempts}
          onClose={() => setShowStatsModal(false)}
        />
      )}

      {/* Minimal Footer */}
      <footer className="w-full border-t border-slate-900 py-4 text-center text-xs text-slate-500">
        BlockIt Pomodoro Lock • Personal Deep Work & Focus System
      </footer>
    </div>
  );
}
